# PT Imuna Kreasi Utama — Company Profile (Multi-page + Charts)

Upload seluruh isi folder ini ke hosting (mis. public_html/), lalu buka index.html.

Halaman:
- index.html      (beranda + line & doughnut chart)
- about.html      (tentang + radar chart)
- services.html   (layanan + bar chart SLA)
- governance.html (tata kelola + line chart)
- contact.html    (kontak + pie chart)

Semua assets via CDN (AdminLTE, Bootstrap, FontAwesome, Chart.js).
